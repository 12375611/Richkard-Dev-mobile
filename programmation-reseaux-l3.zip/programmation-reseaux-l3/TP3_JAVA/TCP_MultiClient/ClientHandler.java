import java.io.*;
import java.net.*;
import java.util.*;

public class ClientHandler extends Thread {

    Socket socket;
    Vector<ClientHandler> clients;

    BufferedReader br;
    PrintWriter pw;

    public ClientHandler(
            Socket socket,
            Vector<ClientHandler> clients
    ){

        this.socket = socket;
        this.clients = clients;

        try {

            br = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()
                    )
            );

            pw = new PrintWriter(
                    socket.getOutputStream(),
                    true
            );

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void run(){

        try {

            String message;

            while((message = br.readLine()) != null){

                System.out.println("Message : " + message);

                for(ClientHandler client : clients){

                    client.pw.println(message);
                }
            }

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}