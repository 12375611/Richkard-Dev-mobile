import java.net.*;
import java.io.*;
import java.util.*;

public class Server {

    static Vector<ClientHandler> clients = new Vector<>();

    public static void main(String[] args) {

        try {

            ServerSocket ss = new ServerSocket(1027);

            System.out.println("Serveur démarré...");

            while(true){

                Socket socket = ss.accept();

                System.out.println("Nouveau client connecté");

                ClientHandler client =
                        new ClientHandler(socket, clients);

                clients.add(client);

                client.start();
            }

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}