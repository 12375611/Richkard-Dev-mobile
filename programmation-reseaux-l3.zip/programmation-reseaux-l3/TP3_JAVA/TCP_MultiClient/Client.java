import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        try {

            Socket socket =
                    new Socket("localhost", 1027);

            BufferedReader br =
                    new BufferedReader(
                            new InputStreamReader(
                                    socket.getInputStream()
                            )
                    );

            PrintWriter pw =
                    new PrintWriter(
                            socket.getOutputStream(),
                            true
                    );

            Scanner sc = new Scanner(System.in);

            Thread lecture = new Thread(() -> {

                try {

                    String msg;

                    while((msg = br.readLine()) != null){

                        System.out.println(
                                "Reçu : " + msg
                        );
                    }

                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
            });

            lecture.start();

            while(true){

                System.out.print("Message : ");

                String message = sc.nextLine();

                pw.println(message);

                if(message.equals("stop")){
                    break;
                }
            }

            socket.close();

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}