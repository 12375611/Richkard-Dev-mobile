import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {

        try {

            DatagramSocket ds = new DatagramSocket();

            InetAddress ip =
                    InetAddress.getByName("localhost");

            Scanner sc = new Scanner(System.in);

            while(true){

                System.out.print("Message : ");
                String msg = sc.nextLine();

                byte[] buffer = msg.getBytes();

                DatagramPacket dp =
                        new DatagramPacket(
                                buffer,
                                buffer.length,
                                ip,
                                9876
                        );

                ds.send(dp);

                if(msg.equals("stop")){
                    break;
                }
            }

            ds.close();

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}