#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>

using namespace std;

int main(int argc, char *argv[]) {

    if(argc < 3){
        cout << "Usage: ./receiver <multicast_ip> <port>" << endl;
        return 1;
    }

    char buffer[1024];

    int sock = socket(AF_INET, SOCK_DGRAM, 0);

    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(atoi(argv[2]));
    addr.sin_addr.s_addr = INADDR_ANY;

    bind(sock, (struct sockaddr*)&addr, sizeof(addr));

    ip_mreq mreq;
    mreq.imr_multiaddr.s_addr = inet_addr(argv[1]);
    mreq.imr_interface.s_addr = INADDR_ANY;

    setsockopt(sock, IPPROTO_IP, IP_ADD_MEMBERSHIP,
               &mreq, sizeof(mreq));

    cout << "En attente des messages..." << endl;

    while(true){

        int len = recv(sock, buffer, sizeof(buffer), 0);

        if(len > 0){
            buffer[len] = '\0';
            cout << "Message reçu : " << buffer << endl;
        }
    }

    close(sock);

    return 0;
}