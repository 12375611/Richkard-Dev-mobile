#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <unistd.h>

using namespace std;

int main(int argc, char *argv[]) {

    if(argc < 3){
        cout << "Usage: ./sender <multicast_ip> <port>" << endl;
        return 1;
    }

    int sock = socket(AF_INET, SOCK_DGRAM, 0);

    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(atoi(argv[2]));
    addr.sin_addr.s_addr = inet_addr(argv[1]);

    string message;

    while(true){

        getline(cin, message);

        sendto(sock,
               message.c_str(),
               message.size(),
               0,
               (struct sockaddr*)&addr,
               sizeof(addr));
    }

    close(sock);

    return 0;
}