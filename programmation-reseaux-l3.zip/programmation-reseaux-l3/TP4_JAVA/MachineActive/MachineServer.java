import java.io.*;
import java.net.*;
import java.time.LocalTime;

public class MachineServer {

    public static void main(String[] args) {

        try {

            ServerSocket ss =
                    new ServerSocket(1027);

            System.out.println("Serveur actif...");

            while(true){

                Socket socket = ss.accept();

                PrintWriter pw =
                        new PrintWriter(
                                socket.getOutputStream(),
                                true
                        );

                pw.println(
                        "Machine active : "
                                + LocalTime.now()
                );

                socket.close();
            }

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}