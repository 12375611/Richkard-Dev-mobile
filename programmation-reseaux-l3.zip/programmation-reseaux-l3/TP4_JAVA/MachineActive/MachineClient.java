import java.io.*;
import java.net.*;
import java.util.Scanner;

public class MachineClient {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        try {

            while(true){

                System.out.print(
                        "Adresse machine : "
                );

                String host = sc.nextLine();

                if(host.equals("stop")){
                    break;
                }

                try {

                    Socket socket =
                            new Socket(host, 1027);

                    BufferedReader br =
                            new BufferedReader(
                                    new InputStreamReader(
                                            socket.getInputStream()
                                    )
                            );

                    String msg = br.readLine();

                    System.out.println(msg);

                    socket.close();

                } catch(Exception ex){

                    System.out.println(
                            "Machine inactive"
                    );
                }
            }

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}