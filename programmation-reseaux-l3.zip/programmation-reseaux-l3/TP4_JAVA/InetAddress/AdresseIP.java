import java.net.*;
import java.util.Scanner;

public class AdresseIP {

    public static void main(String[] args) {

        try {

            InetAddress local =
                    InetAddress.getLocalHost();

            System.out.println(
                    "Adresse locale : "
                            + local.getHostAddress()
            );

            Scanner sc = new Scanner(System.in);

            while(true){

                System.out.print("Nom machine : ");

                String nom = sc.nextLine();

                if(nom.equals("stop")){
                    break;
                }

                InetAddress addr =
                        InetAddress.getByName(nom);

                System.out.println(
                        "Adresse : "
                                + addr.getHostAddress()
                );
            }

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}