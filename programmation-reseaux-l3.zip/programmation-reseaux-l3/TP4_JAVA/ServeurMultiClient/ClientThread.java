import java.io.*;
import java.net.*;
import java.time.LocalDateTime;

public class ClientThread extends Thread {

    Socket socket;

    public ClientThread(Socket socket){

        this.socket = socket;
    }

    public void run(){

        try {

            PrintWriter pw =
                    new PrintWriter(
                            socket.getOutputStream(),
                            true
                    );

            while(true){

                pw.println(
                        "Message serveur : "
                                + LocalDateTime.now()
                );

                Thread.sleep(3000);
            }

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}