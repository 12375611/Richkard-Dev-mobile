import java.io.*;
import java.net.*;

public class MultiClient {

    public static void main(String[] args) {

        try {

            Socket socket =
                    new Socket("localhost", 1026);

            BufferedReader br =
                    new BufferedReader(
                            new InputStreamReader(
                                    socket.getInputStream()
                            )
                    );

            while(true){

                String msg = br.readLine();

                System.out.println(msg);
            }

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}