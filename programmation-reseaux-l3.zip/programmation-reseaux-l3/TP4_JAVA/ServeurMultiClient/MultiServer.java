import java.net.*;
import java.io.*;

public class MultiServer {

    public static void main(String[] args) {

        try {

            ServerSocket ss =
                    new ServerSocket(1026);

            System.out.println(
                    "Serveur multi-client démarré"
            );

            while(true){

                Socket socket = ss.accept();

                ClientThread ct =
                        new ClientThread(socket);

                ct.start();
            }

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}