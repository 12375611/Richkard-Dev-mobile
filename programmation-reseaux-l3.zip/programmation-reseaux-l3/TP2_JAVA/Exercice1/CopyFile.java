import java.io.*;
import java.util.Scanner;

public class CopyFile {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Fichier source : ");
        String in = sc.nextLine();

        System.out.print("Fichier destination : ");
        String out = sc.nextLine();

        try {

            BufferedReader br = new BufferedReader(new FileReader(in));

            PrintStream ps = new PrintStream(out);

            String ligne;

            while((ligne = br.readLine()) != null){
                ps.println(ligne);
            }

            br.close();
            ps.close();

            System.out.println("Copie terminée.");

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}