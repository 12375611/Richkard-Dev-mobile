import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String texte;

        while(true){

            System.out.print("Entrer une chaine : ");
            texte = sc.nextLine();

            if(texte.equals("stop")){
                break;
            }

            System.out.println("Vous avez saisi : " + texte);
        }

        sc.close();
    }
}