import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ClientA {

    public static void main(String[] args) {

        try {

            Socket socket = new Socket("localhost", 1027);

            PrintWriter pw = new PrintWriter(
                    socket.getOutputStream(),
                    true
            );

            Scanner sc = new Scanner(System.in);

            String message;

            while(true){

                System.out.print("Message : ");
                message = sc.nextLine();

                pw.println(message);

                if(message.equals("stop")){
                    break;
                }
            }

            socket.close();

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}