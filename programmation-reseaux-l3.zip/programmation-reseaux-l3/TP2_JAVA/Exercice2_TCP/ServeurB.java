import java.io.*;
import java.net.*;

public class ServeurB {

    public static void main(String[] args) {

        try {

            ServerSocket serveur = new ServerSocket(1027);

            System.out.println("Serveur en attente...");

            Socket socket = serveur.accept();

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(socket.getInputStream())
            );

            String message;

            while((message = br.readLine()) != null){

                if(message.equals("stop")){
                    break;
                }

                System.out.println("Message reçu : " + message);
            }

            socket.close();
            serveur.close();

        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}